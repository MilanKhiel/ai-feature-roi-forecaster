import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Organizations table - multi-tenant container
 */
export const organizations = mysqlTable("organizations", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  ownerId: int("ownerId").notNull().references(() => users.id),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Organization = typeof organizations.$inferSelect;
export type InsertOrganization = typeof organizations.$inferInsert;

/**
 * Organization members with role-based access
 */
export const orgMembers = mysqlTable("orgMembers", {
  id: int("id").autoincrement().primaryKey(),
  orgId: int("orgId").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  role: mysqlEnum("role", ["owner", "member"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type OrgMember = typeof orgMembers.$inferSelect;
export type InsertOrgMember = typeof orgMembers.$inferInsert;

/**
 * Feature ideas with comprehensive context
 */
export const features = mysqlTable("features", {
  id: int("id").autoincrement().primaryKey(),
  orgId: int("orgId").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  createdBy: int("createdBy").notNull().references(() => users.id),
  title: varchar("title", { length: 255 }).notNull(),
  type: mysqlEnum("type", ["acquisition", "activation", "retention", "monetization", "support_cost"]).notNull(),
  problem: text("problem").notNull(),
  targetUsers: text("targetUsers").notNull(),
  successMetric: varchar("successMetric", { length: 100 }).notNull().default("Monthly MRR Delta"),
  effortDays: int("effortDays").notNull(),
  constraints: text("constraints"),
  pricingContext: json("pricingContext").$type<{
    plans?: Array<{ name: string; price: number }>;
  }>(),
  baselineMetrics: json("baselineMetrics").$type<{
    arpa?: number;
    monthlyActiveAccounts?: number;
    trialToPaid?: number;
    churnMonthly?: number;
    supportTicketsMonthly?: number;
  }>(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Feature = typeof features.$inferSelect;
export type InsertFeature = typeof features.$inferInsert;

/**
 * Evidence items supporting feature decisions
 */
export const evidenceItems = mysqlTable("evidenceItems", {
  id: int("id").autoincrement().primaryKey(),
  featureId: int("featureId").notNull().references(() => features.id, { onDelete: "cascade" }),
  sourceType: mysqlEnum("sourceType", ["ticket", "sales_call", "email", "analytics", "other"]).notNull(),
  content: text("content").notNull(),
  link: text("link"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EvidenceItem = typeof evidenceItems.$inferSelect;
export type InsertEvidenceItem = typeof evidenceItems.$inferInsert;

/**
 * AI-generated forecasts with structured output
 */
export const forecasts = mysqlTable("forecasts", {
  id: int("id").autoincrement().primaryKey(),
  featureId: int("featureId").notNull().references(() => features.id, { onDelete: "cascade" }),
  createdBy: int("createdBy").notNull().references(() => users.id),
  roiScore: int("roiScore").notNull(),
  confidence: mysqlEnum("confidence", ["Low", "Medium", "High"]).notNull(),
  impactLow: json("impactLow").$type<{
    metric: string;
    value: number;
    unit: string;
    explanation: string;
  }>().notNull(),
  impactMid: json("impactMid").$type<{
    metric: string;
    value: number;
    unit: string;
    explanation: string;
  }>().notNull(),
  impactHigh: json("impactHigh").$type<{
    metric: string;
    value: number;
    unit: string;
    explanation: string;
  }>().notNull(),
  assumptions: json("assumptions").$type<Array<{
    assumption: string;
    probability: number;
    rationale: string;
    validation: string;
  }>>().notNull(),
  risks: json("risks").$type<Array<{
    risk: string;
    severity: "Low" | "Medium" | "High";
    likelihood: "Low" | "Medium" | "High";
    mitigation: string;
  }>>().notNull(),
  alternatives: json("alternatives").$type<Array<{
    alternative: string;
    whyCheaper: string;
    tradeoff: string;
  }>>().notNull(),
  validationPlan: json("validationPlan").$type<Array<{
    experiment: string;
    timeCost: "Low" | "Medium" | "High";
    moneyCost: "Low" | "Medium" | "High";
    steps: string[];
    successThreshold: string;
  }>>().notNull(),
  decisionMemoMd: text("decisionMemoMd").notNull(),
  rawModelOutput: json("rawModelOutput").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Forecast = typeof forecasts.$inferSelect;
export type InsertForecast = typeof forecasts.$inferInsert;
