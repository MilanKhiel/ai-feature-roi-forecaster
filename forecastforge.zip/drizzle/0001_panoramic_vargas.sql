CREATE TABLE `evidenceItems` (
	`id` int AUTO_INCREMENT NOT NULL,
	`featureId` int NOT NULL,
	`sourceType` enum('ticket','sales_call','email','analytics','other') NOT NULL,
	`content` text NOT NULL,
	`link` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `evidenceItems_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `features` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orgId` int NOT NULL,
	`createdBy` int NOT NULL,
	`title` varchar(255) NOT NULL,
	`type` enum('acquisition','activation','retention','monetization','support_cost') NOT NULL,
	`problem` text NOT NULL,
	`targetUsers` text NOT NULL,
	`successMetric` varchar(100) NOT NULL DEFAULT 'Monthly MRR Delta',
	`effortDays` int NOT NULL,
	`constraints` text,
	`pricingContext` json,
	`baselineMetrics` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `features_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `forecasts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`featureId` int NOT NULL,
	`createdBy` int NOT NULL,
	`roiScore` int NOT NULL,
	`confidence` enum('Low','Medium','High') NOT NULL,
	`impactLow` json NOT NULL,
	`impactMid` json NOT NULL,
	`impactHigh` json NOT NULL,
	`assumptions` json NOT NULL,
	`risks` json NOT NULL,
	`alternatives` json NOT NULL,
	`validationPlan` json NOT NULL,
	`decisionMemoMd` text NOT NULL,
	`rawModelOutput` json NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `forecasts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `orgMembers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`orgId` int NOT NULL,
	`userId` int NOT NULL,
	`role` enum('owner','member') NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `orgMembers_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `organizations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(255) NOT NULL,
	`ownerId` int NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `organizations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
ALTER TABLE `evidenceItems` ADD CONSTRAINT `evidenceItems_featureId_features_id_fk` FOREIGN KEY (`featureId`) REFERENCES `features`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `features` ADD CONSTRAINT `features_orgId_organizations_id_fk` FOREIGN KEY (`orgId`) REFERENCES `organizations`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `features` ADD CONSTRAINT `features_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `forecasts` ADD CONSTRAINT `forecasts_featureId_features_id_fk` FOREIGN KEY (`featureId`) REFERENCES `features`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `forecasts` ADD CONSTRAINT `forecasts_createdBy_users_id_fk` FOREIGN KEY (`createdBy`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `orgMembers` ADD CONSTRAINT `orgMembers_orgId_organizations_id_fk` FOREIGN KEY (`orgId`) REFERENCES `organizations`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `orgMembers` ADD CONSTRAINT `orgMembers_userId_users_id_fk` FOREIGN KEY (`userId`) REFERENCES `users`(`id`) ON DELETE cascade ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `organizations` ADD CONSTRAINT `organizations_ownerId_users_id_fk` FOREIGN KEY (`ownerId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;