-- Row Level Security Policies for ForecastForge
-- Note: MySQL/TiDB doesn't support native RLS like PostgreSQL
-- These policies are implemented as application-level checks in the tRPC procedures
-- This file documents the intended security model

-- ORGANIZATIONS
-- Users can only access organizations they are members of
-- SELECT: WHERE id IN (SELECT orgId FROM orgMembers WHERE userId = current_user_id)
-- INSERT: Allowed for authenticated users (creates their own org)
-- UPDATE: WHERE ownerId = current_user_id
-- DELETE: WHERE ownerId = current_user_id

-- ORG_MEMBERS
-- Users can view members of their own organizations
-- SELECT: WHERE orgId IN (SELECT orgId FROM orgMembers WHERE userId = current_user_id)
-- INSERT: WHERE role = 'owner' AND orgId owned by current_user_id (for invites)
-- UPDATE: Not allowed (use DELETE + INSERT for role changes)
-- DELETE: WHERE orgId owned by current_user_id OR userId = current_user_id (self-removal)

-- FEATURES
-- Users can only access features from their organizations
-- SELECT: WHERE orgId IN (SELECT orgId FROM orgMembers WHERE userId = current_user_id)
-- INSERT: WHERE orgId IN (SELECT orgId FROM orgMembers WHERE userId = current_user_id)
-- UPDATE: WHERE orgId IN (SELECT orgId FROM orgMembers WHERE userId = current_user_id)
-- DELETE: WHERE orgId IN (SELECT orgId FROM orgMembers WHERE userId = current_user_id) AND (createdBy = current_user_id OR current_user_is_owner)

-- EVIDENCE_ITEMS
-- Users can access evidence for features in their organizations
-- SELECT: WHERE featureId IN (SELECT id FROM features WHERE orgId IN user_orgs)
-- INSERT: WHERE featureId IN (SELECT id FROM features WHERE orgId IN user_orgs)
-- UPDATE: WHERE featureId IN (SELECT id FROM features WHERE orgId IN user_orgs)
-- DELETE: WHERE featureId IN (SELECT id FROM features WHERE orgId IN user_orgs)

-- FORECASTS
-- Users can access forecasts for features in their organizations
-- SELECT: WHERE featureId IN (SELECT id FROM features WHERE orgId IN user_orgs)
-- INSERT: WHERE featureId IN (SELECT id FROM features WHERE orgId IN user_orgs)
-- UPDATE: Not allowed (forecasts are immutable)
-- DELETE: WHERE featureId IN (SELECT id FROM features WHERE orgId IN user_orgs) AND current_user_is_owner

-- Implementation notes:
-- All tRPC procedures must verify org membership before performing operations
-- Use helper functions to check: isUserInOrg(userId, orgId) and isUserOrgOwner(userId, orgId)
-- Reject operations with FORBIDDEN error if user lacks access
