# ForecastForge TODO

## Database & Schema
- [x] Define organizations table with owner relationship
- [x] Define org_members table with role enum (owner/member)
- [x] Define profiles table linked to auth users
- [x] Define features table with all required fields
- [x] Define evidence_items table
- [x] Define forecasts table with JSON fields
- [x] Create RLS policies for all tables
- [x] Push schema to database

## Validation
- [x] Create Zod schemas for all database entities
- [x] Create Zod schema for AI forecast output
- [x] Create Zod schemas for form inputs

## Backend Logic
- [x] Implement deterministic base scoring engine (5 subscores)
- [x] Create AI forecast generation function with OpenAI strict JSON mode
- [x] Add retry logic (2 retries) for AI failures
- [x] Add JSON repair fallback for validation errors
- [x] Add timeout handling for AI requests
- [x] Create tRPC procedures for organizations
- [x] Create tRPC procedures for features CRUD
- [x] Create tRPC procedures for evidence items
- [x] Create tRPC procedures for forecast generation
- [x] Create tRPC procedures for forecast history

## Frontend UI
- [x] Design color palette and update theme
- [x] Create dashboard layout with navigation
- [x] Build feature list page with create button
- [x] Build feature creation form with React Hook Form
- [x] Build feature detail page with tabs
- [x] Build evidence collection UI
- [x] Build forecast generation trigger
- [x] Build forecast report display with sections and badges
- [x] Build forecast history list
- [x] Add loading states and error handling
- [x] Add toast notifications

## Authentication & Authorization
- [x] Auto-create organization on first login
- [x] Auto-create profile on first login
- [x] Implement RLS policies enforcement
- [x] Add role-based access checks

## Testing & Documentation
- [x] Write unit tests for scoring engine (minimum 5 tests)
- [x] Write README with setup instructions
- [x] Document forecast logic and scoring rules
- [x] Add environment variable documentation
