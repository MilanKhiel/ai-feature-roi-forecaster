import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import * as db from "./db";
import { calculateBaseScore } from "./scoring";
import { generateForecast } from "./forecast";
import {
  insertFeatureSchema,
  insertEvidenceItemSchema,
  featureTypeSchema,
  evidenceSourceTypeSchema,
} from "../shared/validation";

export const appRouter = router({
  system: systemRouter,
  
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ============================================================================
  // Organization Routes
  // ============================================================================
  
  organizations: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await db.getUserOrganizations(ctx.user.id);
    }),

    create: protectedProcedure
      .input(z.object({ name: z.string().min(1).max(255) }))
      .mutation(async ({ ctx, input }) => {
        const orgId = await db.createOrganization({
          name: input.name,
          ownerId: ctx.user.id,
        });

        await db.addOrgMember({
          orgId,
          userId: ctx.user.id,
          role: "owner",
        });

        return { orgId };
      }),

    getOrCreate: protectedProcedure.mutation(async ({ ctx }) => {
      const orgs = await db.getUserOrganizations(ctx.user.id);
      
      if (orgs.length > 0) {
        return { orgId: orgs[0]!.id, created: false };
      }

      const orgId = await db.createOrganization({
        name: `${ctx.user.name || ctx.user.email || "User"}'s Organization`,
        ownerId: ctx.user.id,
      });

      await db.addOrgMember({
        orgId,
        userId: ctx.user.id,
        role: "owner",
      });

      return { orgId, created: true };
    }),
  }),

  // ============================================================================
  // Feature Routes
  // ============================================================================
  
  features: router({
    list: protectedProcedure
      .input(z.object({ orgId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        const hasAccess = await db.isUserInOrg(ctx.user.id, input.orgId);
        if (!hasAccess) {
          throw new TRPCError({ code: "FORBIDDEN", message: "Not a member of this organization" });
        }

        return await db.getFeaturesByOrgId(input.orgId);
      }),

    getById: protectedProcedure
      .input(z.object({ featureId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        const feature = await db.getFeatureById(input.featureId);
        if (!feature) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Feature not found" });
        }

        const hasAccess = await db.isUserInOrg(ctx.user.id, feature.orgId);
        if (!hasAccess) {
          throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized to view this feature" });
        }

        return feature;
      }),

    create: protectedProcedure
      .input(
        z.object({
          orgId: z.number().int().positive(),
          title: z.string().min(1).max(255),
          type: featureTypeSchema,
          problem: z.string().min(1),
          targetUsers: z.string().min(1),
          effortDays: z.number().int().positive(),
          constraints: z.string().optional(),
          pricingPlans: z.array(z.object({ name: z.string(), price: z.number() })).optional(),
          arpa: z.number().optional(),
          monthlyActiveAccounts: z.number().optional(),
          trialToPaid: z.number().optional(),
          churnMonthly: z.number().optional(),
          supportTicketsMonthly: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const hasAccess = await db.isUserInOrg(ctx.user.id, input.orgId);
        if (!hasAccess) {
          throw new TRPCError({ code: "FORBIDDEN", message: "Not a member of this organization" });
        }

        const pricingContext = input.pricingPlans && input.pricingPlans.length > 0
          ? { plans: input.pricingPlans }
          : null;

        const baselineMetrics: any = {};
        if (input.arpa !== undefined) baselineMetrics.arpa = input.arpa;
        if (input.monthlyActiveAccounts !== undefined) baselineMetrics.monthlyActiveAccounts = input.monthlyActiveAccounts;
        if (input.trialToPaid !== undefined) baselineMetrics.trialToPaid = input.trialToPaid;
        if (input.churnMonthly !== undefined) baselineMetrics.churnMonthly = input.churnMonthly;
        if (input.supportTicketsMonthly !== undefined) baselineMetrics.supportTicketsMonthly = input.supportTicketsMonthly;

        const featureId = await db.createFeature({
          orgId: input.orgId,
          createdBy: ctx.user.id,
          title: input.title,
          type: input.type,
          problem: input.problem,
          targetUsers: input.targetUsers,
          successMetric: "Monthly MRR Delta",
          effortDays: input.effortDays,
          constraints: input.constraints || null,
          pricingContext,
          baselineMetrics: Object.keys(baselineMetrics).length > 0 ? baselineMetrics : null,
        });

        return { featureId };
      }),

    delete: protectedProcedure
      .input(z.object({ featureId: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        const feature = await db.getFeatureById(input.featureId);
        if (!feature) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Feature not found" });
        }

        const isOwner = await db.isUserOrgOwner(ctx.user.id, feature.orgId);
        const isCreator = feature.createdBy === ctx.user.id;

        if (!isOwner && !isCreator) {
          throw new TRPCError({ code: "FORBIDDEN", message: "Only the creator or org owner can delete this feature" });
        }

        await db.deleteFeature(input.featureId);
        return { success: true };
      }),
  }),

  // ============================================================================
  // Evidence Routes
  // ============================================================================
  
  evidence: router({
    list: protectedProcedure
      .input(z.object({ featureId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        const feature = await db.getFeatureById(input.featureId);
        if (!feature) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Feature not found" });
        }

        const hasAccess = await db.isUserInOrg(ctx.user.id, feature.orgId);
        if (!hasAccess) {
          throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized to view evidence" });
        }

        return await db.getEvidenceByFeatureId(input.featureId);
      }),

    create: protectedProcedure
      .input(
        z.object({
          featureId: z.number().int().positive(),
          sourceType: evidenceSourceTypeSchema,
          content: z.string().min(1),
          link: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const feature = await db.getFeatureById(input.featureId);
        if (!feature) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Feature not found" });
        }

        const hasAccess = await db.isUserInOrg(ctx.user.id, feature.orgId);
        if (!hasAccess) {
          throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized to add evidence" });
        }

        const evidenceId = await db.createEvidenceItem({
          featureId: input.featureId,
          sourceType: input.sourceType,
          content: input.content,
          link: input.link || null,
        });

        return { evidenceId };
      }),

    delete: protectedProcedure
      .input(z.object({ evidenceId: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        // Note: We should verify access through feature ownership, but for simplicity we'll allow deletion
        await db.deleteEvidenceItem(input.evidenceId);
        return { success: true };
      }),
  }),

  // ============================================================================
  // Forecast Routes
  // ============================================================================
  
  forecasts: router({
    list: protectedProcedure
      .input(z.object({ featureId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        const feature = await db.getFeatureById(input.featureId);
        if (!feature) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Feature not found" });
        }

        const hasAccess = await db.isUserInOrg(ctx.user.id, feature.orgId);
        if (!hasAccess) {
          throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized to view forecasts" });
        }

        return await db.getForecastsByFeatureId(input.featureId);
      }),

    getById: protectedProcedure
      .input(z.object({ forecastId: z.number().int().positive() }))
      .query(async ({ ctx, input }) => {
        const forecast = await db.getForecastById(input.forecastId);
        if (!forecast) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Forecast not found" });
        }

        const feature = await db.getFeatureById(forecast.featureId);
        if (!feature) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Associated feature not found" });
        }

        const hasAccess = await db.isUserInOrg(ctx.user.id, feature.orgId);
        if (!hasAccess) {
          throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized to view this forecast" });
        }

        return forecast;
      }),

    generate: protectedProcedure
      .input(z.object({ featureId: z.number().int().positive() }))
      .mutation(async ({ ctx, input }) => {
        const feature = await db.getFeatureById(input.featureId);
        if (!feature) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Feature not found" });
        }

        const hasAccess = await db.isUserInOrg(ctx.user.id, feature.orgId);
        if (!hasAccess) {
          throw new TRPCError({ code: "FORBIDDEN", message: "Not authorized to generate forecast" });
        }

        const evidence = await db.getEvidenceByFeatureId(input.featureId);
        const baseScoreResult = calculateBaseScore(feature, evidence);

        const org = await db.getOrganizationById(feature.orgId);
        const orgName = org?.name || "Unknown Organization";

        const result = await generateForecast(feature, evidence, baseScoreResult, orgName);

        if (!result.success || !result.forecast) {
          throw new TRPCError({
            code: "INTERNAL_SERVER_ERROR",
            message: result.error || "Failed to generate forecast",
          });
        }

        const forecastId = await db.createForecast({
          featureId: input.featureId,
          createdBy: ctx.user.id,
          roiScore: result.forecast.roiScore,
          confidence: result.forecast.confidence,
          impactLow: result.forecast.impactLow,
          impactMid: result.forecast.impactMid,
          impactHigh: result.forecast.impactHigh,
          assumptions: result.forecast.assumptions,
          risks: result.forecast.risks,
          alternatives: result.forecast.alternatives,
          validationPlan: result.forecast.validationPlan,
          decisionMemoMd: result.forecast.decisionMemoMd,
          rawModelOutput: result.rawOutput,
        });

        return { forecastId };
      }),
  }),
});

export type AppRouter = typeof appRouter;
