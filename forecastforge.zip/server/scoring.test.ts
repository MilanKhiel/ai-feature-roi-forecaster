import { describe, expect, it } from "vitest";
import { calculateBaseScore } from "./scoring";
import type { Feature, EvidenceItem } from "../drizzle/schema";

function createMockFeature(overrides: Partial<Feature> = {}): Feature {
  return {
    id: 1,
    orgId: 1,
    createdBy: 1,
    title: "Test Feature",
    type: "monetization",
    problem: "Test problem",
    targetUsers: "All users",
    successMetric: "Monthly MRR Delta",
    effortDays: 7,
    constraints: null,
    pricingContext: null,
    baselineMetrics: null,
    createdAt: new Date(),
    updatedAt: new Date(),
    ...overrides,
  };
}

function createMockEvidence(overrides: Partial<EvidenceItem> = {}): EvidenceItem {
  return {
    id: 1,
    featureId: 1,
    sourceType: "analytics",
    content: "Test evidence with data and conversion metrics",
    link: null,
    createdAt: new Date(),
    ...overrides,
  };
}

describe("calculateBaseScore", () => {
  it("should calculate base score for high-value monetization feature", () => {
    const feature = createMockFeature({
      type: "monetization",
      effortDays: 5,
      targetUsers: "All users across all accounts",
      pricingContext: {
        plans: [
          { name: "Basic", price: 29 },
          { name: "Pro", price: 99 },
        ],
      },
      baselineMetrics: {
        arpa: 50,
        monthlyActiveAccounts: 1000,
        churnMonthly: 5,
      },
    });

    const evidence = [
      createMockEvidence({ content: "Analytics data shows 30% conversion increase" }),
      createMockEvidence({ content: "Customer feedback from sales calls" }),
      createMockEvidence({ content: "Support tickets requesting this feature" }),
    ];

    const result = calculateBaseScore(feature, evidence);

    expect(result.baseScore).toBeGreaterThanOrEqual(70);
    expect(result.subscores.valuePotential).toBeGreaterThan(15);
    expect(result.subscores.reach).toBeGreaterThan(15);
    expect(result.subscores.evidenceStrength).toBeGreaterThan(15);
    expect(result.subscores.effortInverse).toBeGreaterThan(12);
    expect(result.subscores.riskPenalty).toBeLessThan(5);
  });

  it("should penalize features with high effort and no evidence", () => {
    const feature = createMockFeature({
      type: "support_cost",
      effortDays: 45,
      targetUsers: "Small subset of power users",
      pricingContext: null,
      baselineMetrics: null,
    });

    const evidence: EvidenceItem[] = [];

    const result = calculateBaseScore(feature, evidence);

    expect(result.baseScore).toBeLessThan(30);
    expect(result.subscores.effortInverse).toBeLessThan(5);
    expect(result.subscores.evidenceStrength).toBe(0);
    expect(result.subscores.riskPenalty).toBeGreaterThan(3);
  });

  it("should handle features with risky constraints", () => {
    const feature = createMockFeature({
      type: "retention",
      effortDays: 14,
      constraints: "Requires security audit, GDPR compliance, and payment infrastructure changes",
      baselineMetrics: null,
    });

    const evidence = [createMockEvidence()];

    const result = calculateBaseScore(feature, evidence);

    expect(result.subscores.riskPenalty).toBeGreaterThan(8);
    expect(result.baseScore).toBeLessThan(60);
  });

  it("should reward features with comprehensive baseline metrics", () => {
    const featureWithMetrics = createMockFeature({
      baselineMetrics: {
        arpa: 75,
        monthlyActiveAccounts: 500,
        trialToPaid: 25,
        churnMonthly: 3,
        supportTicketsMonthly: 120,
      },
    });

    const featureWithoutMetrics = createMockFeature({
      baselineMetrics: null,
    });

    const evidence = [createMockEvidence()];

    const resultWith = calculateBaseScore(featureWithMetrics, evidence);
    const resultWithout = calculateBaseScore(featureWithoutMetrics, evidence);

    expect(resultWith.subscores.valuePotential).toBeGreaterThan(
      resultWithout.subscores.valuePotential
    );
    expect(resultWith.subscores.riskPenalty).toBeLessThan(
      resultWithout.subscores.riskPenalty
    );
  });

  it("should differentiate between broad and niche reach", () => {
    const broadFeature = createMockFeature({
      targetUsers: "All users and everyone in the entire platform",
    });

    const nicheFeature = createMockFeature({
      targetUsers: "Specific subset of enterprise customers with limited use case",
    });

    const evidence = [createMockEvidence()];

    const broadResult = calculateBaseScore(broadFeature, evidence);
    const nicheResult = calculateBaseScore(nicheFeature, evidence);

    expect(broadResult.subscores.reach).toBeGreaterThan(nicheResult.subscores.reach);
    expect(broadResult.subscores.reach).toBeGreaterThanOrEqual(15);
    expect(nicheResult.subscores.reach).toBeLessThanOrEqual(10);
  });

  it("should boost evidence strength with analytics keywords", () => {
    const analyticsEvidence = [
      createMockEvidence({
        sourceType: "analytics",
        content: "Funnel analysis shows conversion drop, cohort data indicates churn",
      }),
      createMockEvidence({ content: "Additional metric tracking" }),
    ];

    const regularEvidence = [
      createMockEvidence({ sourceType: "email", content: "Customer requested this" }),
      createMockEvidence({ sourceType: "ticket", content: "Support ticket" }),
    ];

    const feature = createMockFeature();

    const analyticsResult = calculateBaseScore(feature, analyticsEvidence);
    const regularResult = calculateBaseScore(feature, regularEvidence);

    expect(analyticsResult.subscores.evidenceStrength).toBeGreaterThan(
      regularResult.subscores.evidenceStrength
    );
  });

  it("should clamp base score between 0 and 100", () => {
    const extremeFeature = createMockFeature({
      type: "acquisition",
      effortDays: 100,
      constraints: "security compliance migration payment infrastructure legal regulatory",
      baselineMetrics: null,
    });

    const result = calculateBaseScore(extremeFeature, []);

    expect(result.baseScore).toBeGreaterThanOrEqual(0);
    expect(result.baseScore).toBeLessThanOrEqual(100);
  });
});
