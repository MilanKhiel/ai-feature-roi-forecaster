import type { Feature, EvidenceItem } from "../drizzle/schema";

export interface BaseScoreResult {
  baseScore: number;
  subscores: {
    valuePotential: number;
    reach: number;
    evidenceStrength: number;
    effortInverse: number;
    riskPenalty: number;
  };
}

/**
 * Deterministic base scoring engine
 * Computes 5 subscores (0-20 each) and combines them into a base score (0-100)
 */
export function calculateBaseScore(
  feature: Feature,
  evidence: EvidenceItem[]
): BaseScoreResult {
  const valuePotential = calculateValuePotential(feature);
  const reach = calculateReach(feature);
  const evidenceStrength = calculateEvidenceStrength(evidence);
  const effortInverse = calculateEffortInverse(feature.effortDays);
  const riskPenalty = calculateRiskPenalty(feature);

  const rawScore = valuePotential + reach + evidenceStrength + effortInverse - riskPenalty;
  const baseScore = Math.max(0, Math.min(100, rawScore));

  return {
    baseScore,
    subscores: {
      valuePotential,
      reach,
      evidenceStrength,
      effortInverse,
      riskPenalty,
    },
  };
}

/**
 * Value Potential (0-20)
 * Based on feature type, success metric, pricing context, and baseline metrics
 */
function calculateValuePotential(feature: Feature): number {
  let score = 0;

  // Feature type scoring (0-8)
  const typeScores: Record<string, number> = {
    monetization: 8,
    retention: 7,
    acquisition: 6,
    activation: 5,
    support_cost: 4,
  };
  score += typeScores[feature.type] || 5;

  // Pricing context present (+4)
  if (feature.pricingContext && feature.pricingContext.plans && feature.pricingContext.plans.length > 0) {
    score += 4;
  }

  // Baseline metrics present (+4)
  const metrics = feature.baselineMetrics;
  if (metrics) {
    const metricCount = [
      metrics.arpa,
      metrics.monthlyActiveAccounts,
      metrics.trialToPaid,
      metrics.churnMonthly,
      metrics.supportTicketsMonthly,
    ].filter((m) => m !== undefined && m !== null).length;
    
    score += Math.min(4, metricCount);
  }

  // Success metric is default (+4)
  if (feature.successMetric === "Monthly MRR Delta") {
    score += 4;
  }

  return Math.min(20, score);
}

/**
 * Reach (0-20)
 * Based on target users description
 */
function calculateReach(feature: Feature): number {
  const targetLower = feature.targetUsers.toLowerCase();

  // Broad reach indicators
  const broadKeywords = ["all users", "everyone", "all accounts", "entire", "whole", "every"];
  const hasBroadKeyword = broadKeywords.some((kw) => targetLower.includes(kw));

  // Niche indicators
  const nicheKeywords = ["specific", "select", "few", "small group", "subset", "limited"];
  const hasNicheKeyword = nicheKeywords.some((kw) => targetLower.includes(kw));

  if (hasBroadKeyword) {
    return 18;
  } else if (hasNicheKeyword) {
    return 8;
  } else {
    // Medium reach by default
    return 13;
  }
}

/**
 * Evidence Strength (0-20)
 * Based on evidence count and presence of analytics
 */
function calculateEvidenceStrength(evidence: EvidenceItem[]): number {
  let score = 0;

  // Evidence count (0-12)
  const count = evidence.length;
  if (count === 0) {
    score += 0;
  } else if (count === 1) {
    score += 4;
  } else if (count === 2) {
    score += 7;
  } else if (count === 3) {
    score += 10;
  } else {
    score += 12;
  }

  // Analytics presence (+8)
  const hasAnalytics = evidence.some((e) => {
    const contentLower = e.content.toLowerCase();
    const analyticsKeywords = ["data", "conversion", "churn", "cohort", "funnel", "metric", "analytics"];
    return e.sourceType === "analytics" || analyticsKeywords.some((kw) => contentLower.includes(kw));
  });

  if (hasAnalytics) {
    score += 8;
  }

  return Math.min(20, score);
}

/**
 * Effort Inverse (0-20)
 * Lower effort = higher score
 */
function calculateEffortInverse(effortDays: number): number {
  if (effortDays <= 3) {
    return 20;
  } else if (effortDays <= 7) {
    return 15;
  } else if (effortDays <= 14) {
    return 9;
  } else if (effortDays <= 30) {
    return 4;
  } else {
    return 0;
  }
}

/**
 * Risk Penalty (0-20)
 * Based on constraints keywords and missing baseline metrics
 */
function calculateRiskPenalty(feature: Feature): number {
  let penalty = 0;

  // High-risk constraint keywords
  if (feature.constraints) {
    const constraintsLower = feature.constraints.toLowerCase();
    const riskKeywords = [
      "security",
      "compliance",
      "migration",
      "payment",
      "infrastructure",
      "legal",
      "regulatory",
      "gdpr",
      "pci",
    ];
    const riskCount = riskKeywords.filter((kw) => constraintsLower.includes(kw)).length;
    penalty += Math.min(10, riskCount * 3);
  }

  // Missing baseline metrics penalty
  const metrics = feature.baselineMetrics;
  if (!metrics || Object.keys(metrics).length === 0) {
    penalty += 5;
  } else {
    const metricCount = [
      metrics.arpa,
      metrics.monthlyActiveAccounts,
      metrics.trialToPaid,
      metrics.churnMonthly,
      metrics.supportTicketsMonthly,
    ].filter((m) => m !== undefined && m !== null).length;

    if (metricCount < 2) {
      penalty += 3;
    }
  }

  return Math.min(20, penalty);
}
