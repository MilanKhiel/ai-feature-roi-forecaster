import { invokeLLM } from "./_core/llm";
import { aiForecastOutputSchema, type AIForecastOutput } from "../shared/validation";
import type { Feature, EvidenceItem } from "../drizzle/schema";
import type { BaseScoreResult } from "./scoring";

const FORECAST_TIMEOUT_MS = 60000; // 60 seconds
const MAX_RETRIES = 2;

export interface ForecastGenerationResult {
  success: boolean;
  forecast?: AIForecastOutput;
  rawOutput?: any;
  error?: string;
}

/**
 * Generate AI forecast with retry logic and JSON repair fallback
 */
export async function generateForecast(
  feature: Feature,
  evidence: EvidenceItem[],
  baseScoreResult: BaseScoreResult,
  orgName: string
): Promise<ForecastGenerationResult> {
  let lastError: string = "";
  let lastRawOutput: any = null;

  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    try {
      const result = await generateForecastAttempt(feature, evidence, baseScoreResult, orgName);
      
      // Try to validate with Zod
      try {
        const validated = aiForecastOutputSchema.parse(result);
        return {
          success: true,
          forecast: validated,
          rawOutput: result,
        };
      } catch (validationError: any) {
        lastRawOutput = result;
        lastError = `Validation failed: ${validationError.message}`;
        
        // Attempt JSON repair on first validation failure
        if (attempt === 0) {
          const repaired = attemptJSONRepair(result);
          if (repaired) {
            try {
              const validated = aiForecastOutputSchema.parse(repaired);
              return {
                success: true,
                forecast: validated,
                rawOutput: repaired,
              };
            } catch {
              // Repair didn't help, continue to retry
            }
          }
        }
      }
    } catch (error: any) {
      lastError = error.message || "Unknown error";
      lastRawOutput = null;
    }

    // Wait before retry (exponential backoff)
    if (attempt < MAX_RETRIES) {
      await new Promise((resolve) => setTimeout(resolve, 1000 * (attempt + 1)));
    }
  }

  return {
    success: false,
    rawOutput: lastRawOutput,
    error: lastError,
  };
}

/**
 * Single forecast generation attempt
 */
async function generateForecastAttempt(
  feature: Feature,
  evidence: EvidenceItem[],
  baseScoreResult: BaseScoreResult,
  orgName: string
): Promise<any> {
  const systemPrompt = buildSystemPrompt();
  const userPrompt = buildUserPrompt(feature, evidence, baseScoreResult, orgName);

  const timeoutPromise = new Promise((_, reject) =>
    setTimeout(() => reject(new Error("Forecast generation timeout")), FORECAST_TIMEOUT_MS)
  );

  const llmPromise = invokeLLM({
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userPrompt },
    ],
    response_format: {
      type: "json_schema",
      json_schema: {
        name: "feature_forecast",
        strict: true,
        schema: {
          type: "object",
          properties: {
            roiScore: { type: "integer", description: "ROI score 0-100" },
            confidence: { type: "string", enum: ["Low", "Medium", "High"] },
            confidenceReasoning: { type: "string", description: "Max 240 chars" },
            scoreAdjustmentExplanation: { type: "string" },
            impactLow: {
              type: "object",
              properties: {
                metric: { type: "string" },
                value: { type: "number" },
                unit: { type: "string" },
                explanation: { type: "string" },
              },
              required: ["metric", "value", "unit", "explanation"],
              additionalProperties: false,
            },
            impactMid: {
              type: "object",
              properties: {
                metric: { type: "string" },
                value: { type: "number" },
                unit: { type: "string" },
                explanation: { type: "string" },
              },
              required: ["metric", "value", "unit", "explanation"],
              additionalProperties: false,
            },
            impactHigh: {
              type: "object",
              properties: {
                metric: { type: "string" },
                value: { type: "number" },
                unit: { type: "string" },
                explanation: { type: "string" },
              },
              required: ["metric", "value", "unit", "explanation"],
              additionalProperties: false,
            },
            assumptions: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  assumption: { type: "string" },
                  probability: { type: "number" },
                  rationale: { type: "string" },
                  validation: { type: "string" },
                },
                required: ["assumption", "probability", "rationale", "validation"],
                additionalProperties: false,
              },
            },
            risks: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  risk: { type: "string" },
                  severity: { type: "string", enum: ["Low", "Medium", "High"] },
                  likelihood: { type: "string", enum: ["Low", "Medium", "High"] },
                  mitigation: { type: "string" },
                },
                required: ["risk", "severity", "likelihood", "mitigation"],
                additionalProperties: false,
              },
            },
            alternatives: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  alternative: { type: "string" },
                  whyCheaper: { type: "string" },
                  tradeoff: { type: "string" },
                },
                required: ["alternative", "whyCheaper", "tradeoff"],
                additionalProperties: false,
              },
            },
            validationPlan: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  experiment: { type: "string" },
                  timeCost: { type: "string", enum: ["Low", "Medium", "High"] },
                  moneyCost: { type: "string", enum: ["Low", "Medium", "High"] },
                  steps: { type: "array", items: { type: "string" } },
                  successThreshold: { type: "string" },
                },
                required: ["experiment", "timeCost", "moneyCost", "steps", "successThreshold"],
                additionalProperties: false,
              },
            },
            missingInfo: {
              type: "array",
              items: { type: "string" },
            },
            decisionMemoMd: { type: "string" },
          },
          required: [
            "roiScore",
            "confidence",
            "confidenceReasoning",
            "scoreAdjustmentExplanation",
            "impactLow",
            "impactMid",
            "impactHigh",
            "assumptions",
            "risks",
            "alternatives",
            "validationPlan",
            "missingInfo",
            "decisionMemoMd",
          ],
          additionalProperties: false,
        },
      },
    },
  });

  const response = await Promise.race([llmPromise, timeoutPromise]);
  
  // @ts-ignore - response is from LLM
  const content = response.choices[0]?.message?.content;
  if (!content) {
    throw new Error("Empty response from AI");
  }

  return JSON.parse(content);
}

function buildSystemPrompt(): string {
  return `You are an expert product strategist and ROI analyst. Your task is to forecast the return on investment for SaaS feature ideas.

You will receive:
1. Feature details (type, problem, target users, effort, constraints, pricing, baseline metrics)
2. Supporting evidence (tickets, sales calls, analytics, etc.)
3. A deterministic base score with subscores

Your output MUST be strict JSON matching the provided schema. No additional text or explanations outside the JSON structure.

Guidelines:
- Keep roi_score within ±15 of base_score unless you have strong evidence to deviate (explain in score_adjustment_explanation)
- Confidence should reflect data quality and assumption strength
- Impact ranges (low/mid/high) should be realistic and tied to the success metric
- Rank assumptions by importance and assign realistic probabilities (0-1)
- Rank risks by severity × likelihood
- Provide 2-4 cheaper alternatives with honest tradeoffs
- Order validation experiments by cost/time (cheapest first)
- Keep confidence_reasoning under 240 characters
- List missing_info that would increase confidence
- Write decision_memo_md as a concise executive summary in markdown format`;
}

function buildUserPrompt(
  feature: Feature,
  evidence: EvidenceItem[],
  baseScoreResult: BaseScoreResult,
  orgName: string
): string {
  const evidenceText = evidence.length > 0
    ? evidence.map((e, i) => `${i + 1}. [${e.sourceType}] ${e.content}${e.link ? ` (${e.link})` : ""}`).join("\n")
    : "No evidence provided.";

  const pricingText = feature.pricingContext?.plans
    ? feature.pricingContext.plans.map((p) => `${p.name}: $${p.price}`).join(", ")
    : "Not provided";

  const baselineText = feature.baselineMetrics
    ? Object.entries(feature.baselineMetrics)
        .filter(([_, v]) => v !== undefined && v !== null)
        .map(([k, v]) => `${k}: ${v}`)
        .join(", ")
    : "Not provided";

  return `Organization: ${orgName}

FEATURE DETAILS:
Title: ${feature.title}
Type: ${feature.type}
Problem: ${feature.problem}
Target Users: ${feature.targetUsers}
Success Metric: ${feature.successMetric}
Effort: ${feature.effortDays} days
Constraints: ${feature.constraints || "None"}

PRICING CONTEXT:
${pricingText}

BASELINE METRICS:
${baselineText}

EVIDENCE:
${evidenceText}

BASE SCORE ANALYSIS:
Total Base Score: ${baseScoreResult.baseScore}/100
- Value Potential: ${baseScoreResult.subscores.valuePotential}/20
- Reach: ${baseScoreResult.subscores.reach}/20
- Evidence Strength: ${baseScoreResult.subscores.evidenceStrength}/20
- Effort Inverse: ${baseScoreResult.subscores.effortInverse}/20
- Risk Penalty: -${baseScoreResult.subscores.riskPenalty}/20

Generate a comprehensive ROI forecast for this feature idea.`;
}

/**
 * Attempt to repair malformed JSON
 */
function attemptJSONRepair(obj: any): any | null {
  try {
    // If it's already an object, try to fix common issues
    if (typeof obj === "object" && obj !== null) {
      // Ensure all required fields exist with defaults
      const repaired: any = { ...obj };

      // Fix missing or invalid fields
      if (typeof repaired.roiScore !== "number") {
        repaired.roiScore = 50;
      }
      if (!["Low", "Medium", "High"].includes(repaired.confidence)) {
        repaired.confidence = "Medium";
      }
      if (typeof repaired.confidenceReasoning !== "string") {
        repaired.confidenceReasoning = "Based on available data";
      }
      if (typeof repaired.scoreAdjustmentExplanation !== "string") {
        repaired.scoreAdjustmentExplanation = "";
      }
      if (!Array.isArray(repaired.assumptions)) {
        repaired.assumptions = [];
      }
      if (!Array.isArray(repaired.risks)) {
        repaired.risks = [];
      }
      if (!Array.isArray(repaired.alternatives)) {
        repaired.alternatives = [];
      }
      if (!Array.isArray(repaired.validationPlan)) {
        repaired.validationPlan = [];
      }
      if (!Array.isArray(repaired.missingInfo)) {
        repaired.missingInfo = [];
      }
      if (typeof repaired.decisionMemoMd !== "string") {
        repaired.decisionMemoMd = "Forecast generated with limited data.";
      }

      return repaired;
    }
  } catch {
    return null;
  }
  return null;
}
