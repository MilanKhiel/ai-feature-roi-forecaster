import { z } from "zod";

// ============================================================================
// Database Entity Schemas
// ============================================================================

export const organizationSchema = z.object({
  id: z.number().int().positive(),
  name: z.string().min(1).max(255),
  ownerId: z.number().int().positive(),
  createdAt: z.date(),
  updatedAt: z.date(),
});

export const insertOrganizationSchema = z.object({
  name: z.string().min(1, "Organization name is required").max(255),
  ownerId: z.number().int().positive(),
});

export const orgMemberSchema = z.object({
  id: z.number().int().positive(),
  orgId: z.number().int().positive(),
  userId: z.number().int().positive(),
  role: z.enum(["owner", "member"]),
  createdAt: z.date(),
});

export const insertOrgMemberSchema = z.object({
  orgId: z.number().int().positive(),
  userId: z.number().int().positive(),
  role: z.enum(["owner", "member"]),
});

export const featureTypeSchema = z.enum([
  "acquisition",
  "activation",
  "retention",
  "monetization",
  "support_cost",
]);

export const pricingContextSchema = z.object({
  plans: z.array(
    z.object({
      name: z.string(),
      price: z.number(),
    })
  ).optional(),
}).optional();

export const baselineMetricsSchema = z.object({
  arpa: z.number().optional(),
  monthlyActiveAccounts: z.number().optional(),
  trialToPaid: z.number().optional(),
  churnMonthly: z.number().optional(),
  supportTicketsMonthly: z.number().optional(),
}).optional();

export const featureSchema = z.object({
  id: z.number().int().positive(),
  orgId: z.number().int().positive(),
  createdBy: z.number().int().positive(),
  title: z.string().min(1).max(255),
  type: featureTypeSchema,
  problem: z.string().min(1),
  targetUsers: z.string().min(1),
  successMetric: z.string().min(1).max(100),
  effortDays: z.number().int().positive(),
  constraints: z.string().nullable(),
  pricingContext: pricingContextSchema.nullable(),
  baselineMetrics: baselineMetricsSchema.nullable(),
  createdAt: z.date(),
  updatedAt: z.date(),
});

export const insertFeatureSchema = z.object({
  orgId: z.number().int().positive(),
  createdBy: z.number().int().positive(),
  title: z.string().min(1, "Title is required").max(255),
  type: featureTypeSchema,
  problem: z.string().min(1, "Problem description is required"),
  targetUsers: z.string().min(1, "Target users description is required"),
  successMetric: z.string().min(1).max(100).default("Monthly MRR Delta"),
  effortDays: z.number().int().positive({ message: "Effort must be a positive number" }),
  constraints: z.string().optional(),
  pricingContext: pricingContextSchema,
  baselineMetrics: baselineMetricsSchema,
});

export const evidenceSourceTypeSchema = z.enum([
  "ticket",
  "sales_call",
  "email",
  "analytics",
  "other",
]);

export const evidenceItemSchema = z.object({
  id: z.number().int().positive(),
  featureId: z.number().int().positive(),
  sourceType: evidenceSourceTypeSchema,
  content: z.string().min(1),
  link: z.string().nullable(),
  createdAt: z.date(),
});

export const insertEvidenceItemSchema = z.object({
  featureId: z.number().int().positive(),
  sourceType: evidenceSourceTypeSchema,
  content: z.string().min(1, "Evidence content is required"),
  link: z.string().url("Must be a valid URL").optional().or(z.literal("")),
});

// ============================================================================
// AI Forecast Output Schema (Strict JSON Mode)
// ============================================================================

export const confidenceSchema = z.enum(["Low", "Medium", "High"]);
export const severitySchema = z.enum(["Low", "Medium", "High"]);
export const costSchema = z.enum(["Low", "Medium", "High"]);

export const impactSchema = z.object({
  metric: z.string(),
  value: z.number(),
  unit: z.string(),
  explanation: z.string(),
});

export const assumptionSchema = z.object({
  assumption: z.string(),
  probability: z.number().min(0).max(1),
  rationale: z.string(),
  validation: z.string(),
});

export const riskSchema = z.object({
  risk: z.string(),
  severity: severitySchema,
  likelihood: severitySchema,
  mitigation: z.string(),
});

export const alternativeSchema = z.object({
  alternative: z.string(),
  whyCheaper: z.string(),
  tradeoff: z.string(),
});

export const experimentSchema = z.object({
  experiment: z.string(),
  timeCost: costSchema,
  moneyCost: costSchema,
  steps: z.array(z.string()),
  successThreshold: z.string(),
});

export const aiForecastOutputSchema = z.object({
  roiScore: z.number().int().min(0).max(100),
  confidence: confidenceSchema,
  confidenceReasoning: z.string().max(240),
  scoreAdjustmentExplanation: z.string(),
  impactLow: impactSchema,
  impactMid: impactSchema,
  impactHigh: impactSchema,
  assumptions: z.array(assumptionSchema),
  risks: z.array(riskSchema),
  alternatives: z.array(alternativeSchema),
  validationPlan: z.array(experimentSchema),
  missingInfo: z.array(z.string()),
  decisionMemoMd: z.string(),
});

export type AIForecastOutput = z.infer<typeof aiForecastOutputSchema>;

export const forecastSchema = z.object({
  id: z.number().int().positive(),
  featureId: z.number().int().positive(),
  createdBy: z.number().int().positive(),
  roiScore: z.number().int().min(0).max(100),
  confidence: confidenceSchema,
  impactLow: impactSchema,
  impactMid: impactSchema,
  impactHigh: impactSchema,
  assumptions: z.array(assumptionSchema),
  risks: z.array(riskSchema),
  alternatives: z.array(alternativeSchema),
  validationPlan: z.array(experimentSchema),
  decisionMemoMd: z.string(),
  rawModelOutput: z.any(),
  createdAt: z.date(),
});

export const insertForecastSchema = z.object({
  featureId: z.number().int().positive(),
  createdBy: z.number().int().positive(),
  roiScore: z.number().int().min(0).max(100),
  confidence: confidenceSchema,
  impactLow: impactSchema,
  impactMid: impactSchema,
  impactHigh: impactSchema,
  assumptions: z.array(assumptionSchema),
  risks: z.array(riskSchema),
  alternatives: z.array(alternativeSchema),
  validationPlan: z.array(experimentSchema),
  decisionMemoMd: z.string(),
  rawModelOutput: z.any(),
});

// ============================================================================
// Form Input Schemas
// ============================================================================

export const createFeatureFormSchema = z.object({
  title: z.string().min(1, "Title is required").max(255),
  type: featureTypeSchema,
  problem: z.string().min(1, "Problem description is required"),
  targetUsers: z.string().min(1, "Target users description is required"),
  effortDays: z.number().int().positive({ message: "Effort must be a positive number" }),
  constraints: z.string().optional(),
  pricingPlans: z.array(
    z.object({
      name: z.string().min(1),
      price: z.number().min(0),
    })
  ).optional(),
  arpa: z.number().optional(),
  monthlyActiveAccounts: z.number().optional(),
  trialToPaid: z.number().optional(),
  churnMonthly: z.number().optional(),
  supportTicketsMonthly: z.number().optional(),
});

export type CreateFeatureFormData = z.infer<typeof createFeatureFormSchema>;

export const createEvidenceFormSchema = z.object({
  sourceType: evidenceSourceTypeSchema,
  content: z.string().min(1, "Evidence content is required"),
  link: z.string().url("Must be a valid URL").optional().or(z.literal("")),
});

export type CreateEvidenceFormData = z.infer<typeof createEvidenceFormSchema>;
